import React, { Component } from 'react';
import Square from './Square';
import "../Game.css";

class Board extends React.Component {
  createBoard(row, col) {
    const board = [];
    let cellCounter = 0;

    for (let i = 0; i < row; i += 1) {
      const columns = [];
      for (let j = 0; j < col; j += 1) {
        columns.push(this.renderSquare(cellCounter++));
      }
      board.push(<div key={i} className="board-row">{columns}</div>);
    }

    return board;
  }

  renderSquare(i) {
    const winnerClass =
      this.props.winnerSquares &&
      (this.props.winnerSquares[0] === i ||
        this.props.winnerSquares[1] === i ||
        this.props.winnerSquares[2] === i)
        ? 'square--green'
        : '';

    return (
      <Square
        winnerClass={winnerClass}
        key={i}
        value={this.props.squares[i]}
        onClick={() => this.props.onClick(i)}
      />
    );
  }

  render() {
    return <div>{this.createBoard(3, 3)}</div>;
  }
}



// class Board extends Component {
//     renderSquare = i => (
//           <Square
//             value={ this.props.squares[i] }
//             onClick={ () => this.props.onClick(i) }
//           />
//         );
    
//       render() {
//         const { squares } = this.props;
//         return (
//           <div>
//             <div className="board-row">
//               {this.renderSquare(0)}
//               {this.renderSquare(1)}
//               {this.renderSquare(2)}
//             </div>
//             <div className="board-row">
//               {this.renderSquare(3)}
//               {this.renderSquare(4)}
//               {this.renderSquare(5)}
//             </div>
//             <div className="board-row">
//               {this.renderSquare(6)}
//               {this.renderSquare(7)}
//               {this.renderSquare(8)}
//             </div>
//           </div>
//         );
//       }
// }

export default Board;